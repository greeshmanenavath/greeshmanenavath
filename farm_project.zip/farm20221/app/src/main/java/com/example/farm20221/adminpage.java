package com.example.farm20221;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class adminpage extends AppCompatActivity {

    private TextView nameDisplay, dateDisplay, timeDisplay;
    private Button clearBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminpage);

        // Initialize UI components
        nameDisplay = findViewById(R.id.nameDisplay);
        dateDisplay = findViewById(R.id.dateDisplay);
        timeDisplay = findViewById(R.id.timeDisplay);
        clearBtn = findViewById(R.id.clearBtn);

        // Retrieve stored booking details from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("BookingDetails", MODE_PRIVATE);
        String name = sharedPreferences.getString("name", "No name entered");
        String date = sharedPreferences.getString("date", "No date selected");
        String time = sharedPreferences.getString("time", "No time selected");

        // Display the stored details in the TextViews
        nameDisplay.setText("Name: " + name);
        dateDisplay.setText("Date: " + date);
        timeDisplay.setText("Time: " + time);

        // Set action for Clear button
        clearBtn.setOnClickListener(v -> {
            // Clear the displayed details
            nameDisplay.setText("Name: ");
            dateDisplay.setText("Date: ");
            timeDisplay.setText("Time: ");

            // Clear stored details from SharedPreferences
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.remove("name");
            editor.remove("date");
            editor.remove("time");
            editor.apply();

            // Display confirmation message
            nameDisplay.setText("Name: ");
            dateDisplay.setText("Date: ");
            timeDisplay.setText("Time: ");
        });
    }
}
