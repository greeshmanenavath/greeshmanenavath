package com.example.farm20221;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class nearlocation extends AppCompatActivity {

    Button loc1, loc2, loc3, loc4, booking1, booking2, booking3, booking4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nearlocation);

        // Initialize location buttons
        loc1 = findViewById(R.id.l1);
        loc2 = findViewById(R.id.l2);
        loc3 = findViewById(R.id.l3);
        loc4 = findViewById(R.id.l4);

        // Initialize booking buttons
        booking1 = findViewById(R.id.button2);
        booking2 = findViewById(R.id.button3);
        booking3 = findViewById(R.id.button4);
        booking4 = findViewById(R.id.button5);

        // Location button click listeners
        loc1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://www.google.com/maps/search/presidency+university/@13.0270942,77.592962,22242m/data=!3m2!1e3!4b1?entry=ttu&g_ep=EgoyMDI0MTEwNi4wIKXMDSoASAFQAw%3D%3D");
            }
        });

        loc2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://www.google.com/maps/search/presidency+university/@13.0270942,77.592962,22242m/data=!3m2!1e3!4b1?entry=ttu&g_ep=EgoyMDI0MTEwNi4wIKXMDSoASAFQAw%3D%3D");
            }
        });

        loc3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://www.google.com/maps/search/presidency+university/@13.0270942,77.592962,22242m/data=!3m2!1e3!4b1?entry=ttu&g_ep=EgoyMDI0MTEwNi4wIKXMDSoASAFQAw%3D%3D");
            }
        });

        loc4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoUrl("https://www.google.com/maps/search/presidency+university/@13.0270942,77.592962,22242m/data=!3m2!1e3!4b1?entry=ttu&g_ep=EgoyMDI0MTEwNi4wIKXMDSoASAFQAw%3D%3D");
            }
        });

        // Booking button click listeners
        booking1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToBookingPage();
            }
        });

        booking2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToBookingPage();
            }
        });

        booking3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToBookingPage();
            }
        });

        booking4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToBookingPage();
            }
        });
    }

    private void gotoUrl(String url) {
        Uri uri = Uri.parse(url);
        startActivity(new Intent(Intent.ACTION_VIEW, uri));
    }

    private void goToBookingPage() {
        Intent intent = new Intent(nearlocation.this, booking.class);
        startActivity(intent);
    }
}
