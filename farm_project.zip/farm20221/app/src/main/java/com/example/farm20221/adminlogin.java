package com.example.farm20221;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class adminlogin extends AppCompatActivity {

    private EditText email, password;
    private Button login, back;

    // Admin credentials
    private final String ADMIN_EMAIL = "admin@gmail.com";
    private final String ADMIN_PASSWORD = "admin123";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminlogin);

        // Initialize UI components
        email = findViewById(R.id.etadminemail);
        password = findViewById(R.id.etadminpass);
        login = findViewById(R.id.adminlogin);
        back = findViewById(R.id.btfarmerbac);

        // Back button logic
        back.setOnClickListener(v -> startActivity(new Intent(adminlogin.this, MainActivity.class)));

        // Login button logic
        login.setOnClickListener(v -> {
            String inputEmail = email.getText().toString().trim();
            String inputPassword = password.getText().toString().trim();

            if (inputEmail.isEmpty() || inputPassword.isEmpty()) {
                Toast.makeText(adminlogin.this, "Please enter both email and password", Toast.LENGTH_SHORT).show();
            } else if (inputEmail.equals(ADMIN_EMAIL) && inputPassword.equals(ADMIN_PASSWORD)) {
                // Redirect to Admin Page
                Toast.makeText(adminlogin.this, "Welcome Admin!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(adminlogin.this, adminpage.class));
                finish();
            } else {
                // Show warning that the user is not an admin
                Toast.makeText(adminlogin.this, "You are not an admin!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
