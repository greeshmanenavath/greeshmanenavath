package com.example.farm20221;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class crops extends AppCompatActivity {

    private Spinner spinner;
    private EditText amountInKg, pricePerKg;
    private Button locationButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crops);

        // Initialize UI components
        spinner = findViewById(R.id.spinner);
        amountInKg = findViewById(R.id.amountinkg);
        pricePerKg = findViewById(R.id.price);
        locationButton = findViewById(R.id.location);

        // Add crop names to the Spinner
        String[] crops = {"Wheat", "Rice", "Maize", "Barley", "Soybeans"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, crops);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        // Spinner item selection listener (optional)
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedCrop = parent.getItemAtPosition(position).toString();
                Toast.makeText(crops.this, "Selected Crop: " + selectedCrop, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });

        // Handle location button click
        locationButton.setOnClickListener(v -> {
            String amountText = amountInKg.getText().toString();
            String priceText = pricePerKg.getText().toString();

            if (amountText.isEmpty() || priceText.isEmpty()) {
                Toast.makeText(crops.this, "Please enter both amount and price", Toast.LENGTH_SHORT).show();
            } else {
                try {
                    // Calculate total amount
                    double amount = Double.parseDouble(amountText);
                    double price = Double.parseDouble(priceText);
                    double totalPrice = amount * price;

                    Toast.makeText(crops.this, "Total Price: " + totalPrice + " units", Toast.LENGTH_SHORT).show();

                    // Redirect to location.java
                    Intent intent = new Intent(crops.this, nearlocation.class);
                    startActivity(intent);
                } catch (NumberFormatException e) {
                    Toast.makeText(crops.this, "Invalid input. Please enter valid numbers.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
