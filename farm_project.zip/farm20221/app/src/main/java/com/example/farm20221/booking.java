package com.example.farm20221;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class booking extends AppCompatActivity {

    private EditText nameInput;
    private Button selectDateBtn, selectTimeBtn, submitBtn;
    private String selectedDate = "", selectedTime = "";
    private String enteredName = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booking);

        // Initialize UI components
        nameInput = findViewById(R.id.nameInput);
        selectDateBtn = findViewById(R.id.selectDateBtn);
        selectTimeBtn = findViewById(R.id.selectTimeBtn);
        submitBtn = findViewById(R.id.submitBtn);

        // Set date picker button click listener
        selectDateBtn.setOnClickListener(v -> {
            // Get the current date
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            int month = calendar.get(Calendar.MONTH);
            int day = calendar.get(Calendar.DAY_OF_MONTH);

            // Open DatePickerDialog
            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    booking.this,
                    (view, year1, month1, dayOfMonth) -> {
                        // Format the selected date
                        selectedDate = dayOfMonth + "-" + (month1 + 1) + "-" + year1;
                        selectDateBtn.setText("Date: " + selectedDate);
                    },
                    year, month, day);
            datePickerDialog.show();
        });

        // Set time picker button click listener
        selectTimeBtn.setOnClickListener(v -> {
            // Get the current time
            Calendar calendar = Calendar.getInstance();
            int hour = calendar.get(Calendar.HOUR_OF_DAY);
            int minute = calendar.get(Calendar.MINUTE);

            // Open TimePickerDialog
            TimePickerDialog timePickerDialog = new TimePickerDialog(
                    booking.this,
                    (view, hourOfDay, minute1) -> {
                        // Format the selected time
                        selectedTime = String.format("%02d:%02d", hourOfDay, minute1);
                        selectTimeBtn.setText("Time: " + selectedTime);
                    },
                    hour, minute, true);
            timePickerDialog.show();
        });

        // Submit button action
        submitBtn.setOnClickListener(v -> {
            enteredName = nameInput.getText().toString();

            if (enteredName.isEmpty()) {
                Toast.makeText(booking.this, "Please enter your name", Toast.LENGTH_SHORT).show();
                return;
            }

            if (selectedDate.isEmpty() || selectedTime.isEmpty()) {
                Toast.makeText(booking.this, "Please select both date and time", Toast.LENGTH_SHORT).show();
                return;
            }

            // Store details in SharedPreferences
            SharedPreferences sharedPreferences = getSharedPreferences("BookingDetails", MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("name", enteredName);
            editor.putString("date", selectedDate);
            editor.putString("time", selectedTime);
            editor.apply();

            // Display a confirmation message
            Toast.makeText(booking.this, "Booking details saved", Toast.LENGTH_SHORT).show();
        });
    }
}
